module org.jgrapht.demo
{
    exports org.jgrapht.demo;

    requires transitive org.jgrapht.core;
    requires transitive org.jgrapht.io;
    requires transitive org.jgrapht.ext;

    requires java.desktop;
}

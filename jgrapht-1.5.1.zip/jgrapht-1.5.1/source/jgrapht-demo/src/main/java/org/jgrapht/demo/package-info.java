/**
 * Demo programs that help to get started with <b>JGraphT</b>.
 */
package org.jgrapht.demo;

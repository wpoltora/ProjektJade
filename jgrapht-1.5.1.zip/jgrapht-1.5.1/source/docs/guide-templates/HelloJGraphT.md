---
title: Hello JGraphT Complete Example
---

# {{ page.title }}

```java
:[source code](http://code.jgrapht.org/raw/master/jgrapht-demo/src/main/java/org/jgrapht/demo/HelloJGraphT.java)
```

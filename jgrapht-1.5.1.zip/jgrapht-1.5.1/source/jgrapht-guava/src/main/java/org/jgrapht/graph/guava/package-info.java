/**
 * <a href="https://jgrapht.org/guide/UserOverview#guava-graph-adapter">Guava adapters</a> allow you
 * to <a href="https://jgrapht.org/guide/GuavaAdapter">run JGraphT algorithms directly against
 * Guava's common.graph data structures</a>.
 */
package org.jgrapht.graph.guava;
